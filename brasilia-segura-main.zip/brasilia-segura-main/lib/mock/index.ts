// Exportar todos os dados mockados de um único lugar
export * from './regions';
export * from './categories';
export * from './reports';
export * from './users';
export * from './statistics';